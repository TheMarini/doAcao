![DoAção Logo](logo-git.png)
# Um novo jeito de doar!/A new way to donate!
O projeto DoAção nasceu a partir da busca de um meio para facilitar a conexão entre doadores com instituições que promovem a filantropia. Um site simples em que as pessoas podem colocar seus objetos para doação, ficando a cargo do sistema encontrar instituições que os necessitam e intermediar todo o processo.

Este projeto foi utilizado como Trabalho de Conclusão de Curso do ETIM da ETEC Aristóteles Ferreira  - Santos/SP

The Project ShareIt born to find a way to make the donation process easier.

## Equipe/Staff
 - Esdras Nani
 - Luana Reis
 - Bruno Marini
 - Bruno Thomaz
 - Vinícius Teixeira

## Tecnologias Empregadas/Tecnologies
 - HTML/CSS
 - JAVASCRIPT/JQUERY
 - PHP MVC
 
