<?php
namespace prjDoacao\app\Views\usuario;

use prjDoacao\sys\View as View;

/**
 * For not logged cases
 */
class notLogged extends View
{
    
}
